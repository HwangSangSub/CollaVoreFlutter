import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart';

import './provider/loginProvider.dart';
import './provider/BottomNavigationProvider.dart';

import './screens/member/login.dart';
// import './screens/member/join.dart';
// import './screens/member/reg.dart';
// import './screens/project/list.dart';
import './screens/cals/list.dart';
import './screens/appr/list.dart';
import './screens/project/list.dart';

main() async {
  await initializeDateFormatting();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginProvider()),
        //ChangeNotifierProvider(create: (_) => BottomNavigationProvider()),
      ],
      child: Main(),
    ),
  );
}

class Main extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Provider<String>.value(
      value: 'Shared Data',
      child: MaterialApp(
        title: 'CollaVoer',
        initialRoute: '/login',
        routes: {
          '/login': (context) => LoginPage(),
          // '/join': (context) => JoinPage(),
          // '/reg': (context) => RegPage(),
          '/cals/list': (context) => CalsPage(),
          '/project/list': (context) => ProjectPage(),
          '/appr/list': (context) => ApprPage(),
          // '/info': (context) => InfoPage(),
          // '/modify': (context) => ModifyPage(),
          // '/myPage': (context) => MyPage(),
        },
      ),
    );
  }
}
