import 'package:flutter/material.dart';

class MenuBottom extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MenuBottomState();
}

class _MenuBottomState extends State<MenuBottom> {
  int _curIndex = 0;
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: _curIndex,
      onTap: (int index) {
        setState(() {
          _curIndex = index;
        }); // => build 함수를 다시 호출
        // switch (index) {
        //   case 0:
        //     Navigator.pushNamed(context, '/cals/list');
        //     break;
        //   case 1:
        //     Navigator.pushNamed(context, '/project/list');
        //     break;
        //   case 2:
        //     Navigator.pushNamed(context, '/appr/list');
        //     break;
        // }
      },
      showSelectedLabels: true,
      items: [
        BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
            size: 30,
            color: _curIndex == 0 ? Colors.blue : Colors.black54,
          ),
          label: '일정',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
            size: 30,
            color: _curIndex == 1 ? Colors.red : Colors.black54,
          ),
          label: '프로젝트',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
            size: 30,
            color: _curIndex == 2 ? Colors.green : Colors.black54,
          ),
          label: '전자결재',
        ),
      ],
    );
  }
}
